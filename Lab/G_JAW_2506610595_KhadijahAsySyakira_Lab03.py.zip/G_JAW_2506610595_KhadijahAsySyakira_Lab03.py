# Menerima data pengguna
judul = "Sistem Verifikasi Akun"
print(f"{judul:=^30}")
name = input("Masukkan nama lengkap: ")
telepon = input("Nomor telepon: ")

name_splitted = name.split()
first_name = name_splitted[0]
last_name = name_splitted[1]

kunci_verifikasi = first_name[:2] + str(ord(last_name[0])) + telepon[-3::]
kata_sandi = first_name[-2::] + "_"*len(first_name) + telepon[2:6]

input_verifikasi = input("Masukkan Kunci Verifikasi Anda: ")
input_sandi = input("Masukkan Kata Sandi Anda: ")

print("---Hasil Verifikasi Akun-")
username = "Username"
nomor_telepon = "Nomor telepon"
telepon_cencored = telepon.replace(telepon[2:8], "*"*6)
absolute = "|"
if (input_verifikasi == kunci_verifikasi) and (input_sandi == kata_sandi):
    print(f"| {username:<15}|{first_name:>15} |")
    print(f"|{absolute:-^34}|")
    print(f"| {nomor_telepon:<15}|{telepon_cencored:>15} |")
    print(f"Selamat datang {first_name}!")
    print(f"Nomor telepon {telepon_cencored} terverifikasi!")
else:
    print("Verifikasi Gagal!")
    if input_verifikasi != kunci_verifikasi:
        print("Kunci Verifikasi Salah!")
    if input_sandi != kata_sandi:
        print("Kata Sandi Salah")
